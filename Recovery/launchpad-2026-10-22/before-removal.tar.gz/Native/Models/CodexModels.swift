import Foundation

enum CodexPhoneTheme: String, CaseIterable, Codable, Identifiable, Sendable {
    case classic
    case pixelSpace
    case dotMatrix
    case pixelQuest
    case controlCabinet
    case dotConsole

    var id: String { rawValue }

    var title: String {
        switch self {
        case .classic: "기본"
        case .pixelSpace: "오비탈 픽셀"
        case .dotMatrix: "도트 매트릭스"
        case .pixelQuest: "픽셀 퀘스트"
        case .controlCabinet: "컨트롤 캐비넷"
        case .dotConsole: "도트 콘솔"
        }
    }

    var subtitle: String {
        switch self {
        case .classic: "현재의 깔끔한 Codex 화면"
        case .pixelSpace: "우주 정거장과 픽셀 에너지 모션"
        case .dotMatrix: "도트 그리드와 픽셀 체크 모션"
        case .pixelQuest: "스테이지 HUD와 아케이드 퀘스트"
        case .controlCabinet: "제어반 배선과 회전 로터·표시등"
        case .dotConsole: "도트 그래픽과 한도·재설정 전용 패널"
        }
    }
}

enum CodexActivity: String, CaseIterable, Codable, Identifiable, Sendable {
    case idle
    case connecting
    case running
    case waitingForApproval
    case completed
    case failed

    var id: String { rawValue }

    var title: String {
        switch self {
        case .idle: "대기"
        case .connecting: "연결 중"
        case .running: "작업 중"
        case .waitingForApproval: "승인 대기"
        case .completed: "완료"
        case .failed: "오류"
        }
    }
}

enum CodexEventReducer {
    static func activity(for method: String) -> CodexActivity? {
        let normalized = method.lowercased()
        if normalized == "turn/completed" { return .completed }
        if normalized == "turn/failed"
            || normalized == "turn/cancelled"
            || normalized == "turn/interrupted"
            || normalized == "turn/aborted" { return .failed }
        if normalized.contains("approval")
            || normalized.contains("requestuserinput")
            || normalized.contains("awaitinginput")
            || normalized.contains("confirmation") { return .waitingForApproval }

        // App Server streams progress through turn/*, item/*, and realtime/raw
        // response notifications. Any of these means Codex is still doing work;
        // item/completed and rawResponse/completed happen before turn/completed.
        if normalized.hasPrefix("turn/")
            || normalized.hasPrefix("item/")
            || normalized.hasPrefix("thread/realtime/")
            || normalized.hasPrefix("rawresponse/") {
            return .running
        }
        return nil
    }
}

enum CodexMotionReentryPolicy {
    static func shouldRestart(for activity: CodexActivity) -> Bool {
        switch activity {
        case .connecting, .running, .waitingForApproval: true
        case .idle, .completed, .failed: false
        }
    }
}

struct DesktopCodexTaskID: Hashable, Sendable {
    let transcriptID: String
    let turnID: String
}

enum DesktopCodexTaskLifecycleEvent: Equatable, Sendable {
    case started(DesktopCodexTaskID)
    case completed(DesktopCodexTaskID)
}

struct DesktopCodexTaskParser {
    static let maximumIncompleteRecordByteCount = 256 * 1_024

    let transcriptID: String
    private var sessionID: String?
    private var transcriptInstanceID: String?
    private var bufferedData = Data()
    private var isDiscardingOverlongRecord = false
    private var transcriptIsEligible: Bool?
    private(set) var activeTaskIDs: Set<DesktopCodexTaskID> = []
    private var completedTaskIDs: Set<DesktopCodexTaskID> = []
    private var activeTaskStartOrder: [DesktopCodexTaskID] = []
    private(set) var discardedOverlongRecordCount = 0

    /// A session ID from `session_meta` is stable across rollout copies and
    /// lets the monitor safely treat turns in that transcript as sequential.
    var hasStableSessionID: Bool { sessionID != nil }

    /// Only the canonical root transcript is authoritative when restoring
    /// active work. Child rollout copies can omit the later completion record.
    var restoresActiveTasksOnStartup: Bool {
        guard let sessionID, let transcriptInstanceID else { return true }
        return sessionID == transcriptInstanceID
    }

    var activeTaskIDsInStartOrder: [DesktopCodexTaskID] {
        activeTaskStartOrder.filter { activeTaskIDs.contains($0) }
    }

    init(transcriptID: String) {
        self.transcriptID = transcriptID
    }

    mutating func primeInitialMetadata(from data: Data) {
        guard transcriptIsEligible == nil else { return }

        var remainingData = data[...]
        while let newlineIndex = remainingData.firstIndex(of: 10) {
            let line = Data(remainingData[..<newlineIndex])
            remainingData = remainingData[remainingData.index(after: newlineIndex)...]
            guard line.count <= Self.maximumIncompleteRecordByteCount,
                  !line.isEmpty,
                  let object = try? JSONSerialization.jsonObject(with: line),
                  let record = object as? [String: Any],
                  record["type"] as? String == "session_meta" else {
                continue
            }

            consumeMetadata(record)
            if transcriptIsEligible != nil { return }
        }
    }

    mutating func consume(_ data: Data) -> [DesktopCodexTaskLifecycleEvent] {
        bufferedData.append(data)
        var events: [DesktopCodexTaskLifecycleEvent] = []

        while true {
            if isDiscardingOverlongRecord {
                guard let newlineIndex = bufferedData.firstIndex(of: 10) else {
                    bufferedData.removeAll(keepingCapacity: true)
                    break
                }
                bufferedData.removeSubrange(...newlineIndex)
                isDiscardingOverlongRecord = false
                continue
            }

            guard let newlineIndex = bufferedData.firstIndex(of: 10) else {
                if bufferedData.count > Self.maximumIncompleteRecordByteCount {
                    bufferedData.removeAll(keepingCapacity: true)
                    isDiscardingOverlongRecord = true
                    discardedOverlongRecordCount += 1
                }
                break
            }

            let line = Data(bufferedData[..<newlineIndex])
            bufferedData.removeSubrange(...newlineIndex)
            guard line.count <= Self.maximumIncompleteRecordByteCount else {
                discardedOverlongRecordCount += 1
                continue
            }
            if let event = consumeRecord(line) {
                events.append(event)
            }
        }

        return events
    }

    private mutating func consumeRecord(_ line: Data) -> DesktopCodexTaskLifecycleEvent? {
        guard !line.isEmpty,
              let object = try? JSONSerialization.jsonObject(with: line),
              let record = object as? [String: Any],
              let recordType = record["type"] as? String else {
            return nil
        }

        if recordType == "session_meta" {
            consumeMetadata(record)
            return nil
        }

        guard transcriptIsEligible == true,
              let payload = record["payload"] as? [String: Any],
              let rawTurnID = payload["turn_id"] as? String else {
            return nil
        }

        let turnID = rawTurnID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !turnID.isEmpty else { return nil }

        let taskID = DesktopCodexTaskID(transcriptID: sessionID ?? transcriptID, turnID: turnID)
        if recordType == "turn_context" {
            return beginTask(taskID)
        }

        guard recordType == "event_msg",
              let eventType = payload["type"] as? String else {
            return nil
        }

        switch eventType {
        case "task_started":
            return beginTask(taskID)
        case "task_complete", "turn_aborted":
            // A completion can be observed without its start when monitoring
            // begins mid-transcript. Ignore it instead of creating a false
            // completed state for the whole desktop activity.
            guard activeTaskIDs.remove(taskID) != nil,
                  completedTaskIDs.insert(taskID).inserted else { return nil }
            activeTaskStartOrder.removeAll { $0 == taskID }
            return .completed(taskID)
        default:
            // Progress records such as item_started/item_completed can be
            // the first observable record when task_started was flushed in a
            // different write. They still prove that this turn is active.
            guard Self.isProgressEvent(eventType) else { return nil }
            return activeTaskIDs.contains(taskID) ? nil : beginTask(taskID)
        }
    }

    private static func isProgressEvent(_ eventType: String) -> Bool {
        eventType == "token_count"
            || eventType == "context_compacted"
            || eventType.hasPrefix("item_")
            || eventType.hasPrefix("agent_")
            || eventType.hasPrefix("command_")
            || eventType.hasPrefix("tool_")
            || eventType.hasPrefix("file_")
    }

    private mutating func beginTask(_ taskID: DesktopCodexTaskID) -> DesktopCodexTaskLifecycleEvent? {
        guard !activeTaskIDs.contains(taskID) else { return nil }
        if sessionID != nil {
            activeTaskIDs.removeAll()
            activeTaskStartOrder.removeAll()
        }
        activeTaskIDs.insert(taskID)
        completedTaskIDs.remove(taskID)
        activeTaskStartOrder.append(taskID)
        return .started(taskID)
    }

    private mutating func consumeMetadata(_ record: [String: Any]) {
        guard transcriptIsEligible == nil,
              let payload = record["payload"] as? [String: Any],
              let originator = payload["originator"] as? String,
              let threadSource = payload["thread_source"] as? String else {
            return
        }

        transcriptInstanceID = payload["id"] as? String
        for key in ["session_id", "parent_thread_id", "id"] {
            if let id = payload[key] as? String, !id.isEmpty {
                sessionID = id
                break
            }
        }

        // Only the user's root session represents the phone-tracked task.
        // Subagent, review, and guardian sessions are internal observations
        // and must not publish their short-lived terminal events as
        // user-task completion.
        transcriptIsEligible = originator == "Codex Desktop"
            && threadSource == "user"
    }
}

struct CodexActivityCoordinator {
    private var appServerActivity: CodexActivity = .idle
    private var desktopActiveTaskIDs: Set<DesktopCodexTaskID> = []
    private var desktopTerminalActivity: CodexActivity?
    private(set) var activity: CodexActivity = .idle

    @discardableResult
    mutating func consume(_ events: [DesktopCodexTaskLifecycleEvent]) -> CodexActivity {
        for event in events {
            switch event {
            case let .started(taskID):
                if desktopActiveTaskIDs.insert(taskID).inserted {
                    desktopTerminalActivity = nil
                }
            case let .completed(taskID):
                desktopActiveTaskIDs.remove(taskID)
                if desktopActiveTaskIDs.isEmpty {
                    desktopTerminalActivity = .completed
                }
            }
        }
        activity = effectiveActivity
        return activity
    }

    @discardableResult
    mutating func updateAppServerActivity(_ activity: CodexActivity) -> CodexActivity {
        let previousAppServerActivity = appServerActivity
        appServerActivity = activity
        switch activity {
        case .connecting, .running, .waitingForApproval:
            // The app server may keep emitting its last `running` state after
            // the desktop transcript has already completed. Preserve that
            // terminal desktop result across an active-to-active refresh; a
            // transition from an idle/terminal state still represents new
            // app-server work and clears the old terminal marker.
            let wasAlreadyActive = switch previousAppServerActivity {
            case .connecting, .running, .waitingForApproval: true
            case .idle, .completed, .failed: false
            }
            if !wasAlreadyActive { desktopTerminalActivity = nil }
        case .idle, .completed, .failed:
            break
        }
        self.activity = effectiveActivity
        return self.activity
    }

    private var effectiveActivity: CodexActivity {
        if !desktopActiveTaskIDs.isEmpty {
            return .running
        }

        // Desktop transcript events are the source of truth for Desktop tasks.
        // A running App Server status can be left behind after such a task finishes.
        if appServerActivity == .running {
            return desktopTerminalActivity ?? .running
        }

        switch appServerActivity {
        case .waitingForApproval, .failed, .completed:
            return appServerActivity
        case .idle, .connecting, .running:
            return desktopTerminalActivity ?? appServerActivity
        }
    }
}

enum CodexMotionDismissal: String, CaseIterable, Codable, Identifiable {
    case afterDuration
    case anyPad
    case assignedPad

    var id: String { rawValue }

    var title: String {
        switch self {
        case .afterDuration: "시간 후 종료"
        case .anyPad: "아무 버튼까지"
        case .assignedPad: "지정 버튼까지"
        }
    }
}

enum CodexMotionDisplayScope: String, CaseIterable, Codable, Identifiable {
    case allPages
    case specificPage

    var id: String { rawValue }

    var title: String {
        switch self {
        case .allPages: "모든 페이지"
        case .specificPage: "특정 페이지"
        }
    }
}

struct CodexWeeklyUsage: Equatable, Sendable {
    var usedPercent: Int
    var resetsAt: Date?
}

struct CodexFiveHourUsage: Equatable, Sendable {
    var usedPercent: Int
    var resetsAt: Date?
}

enum CodexWeeklyUsageGrid {
    private static let digitPixels: [Character: [String]] = [
        "0": ["111", "101", "101", "101", "111"],
        "1": ["010", "110", "010", "010", "111"],
        "2": ["111", "001", "111", "100", "111"],
        "3": ["111", "001", "111", "001", "111"],
        "4": ["101", "101", "111", "001", "001"],
        "5": ["111", "100", "111", "001", "111"],
        "6": ["111", "100", "111", "101", "111"],
        "7": ["111", "001", "010", "010", "010"],
        "8": ["111", "101", "111", "101", "111"],
        "9": ["111", "101", "111", "001", "111"]
    ]

    static func remainingCellCount(usedPercent: Int) -> Int {
        let clampedUsedPercent = min(max(usedPercent, 0), 100)
        return Int((Double(100 - clampedUsedPercent) * 64 / 100).rounded(.up))
    }

    static func isRemainingCellActive(index: Int, remainingCellCount: Int) -> Bool {
        guard (0..<64).contains(index) else { return false }
        return index >= 64 - min(max(remainingCellCount, 0), 64)
    }

    static func numericPixels(remainingPercent: Int) -> [Bool] {
        let normalizedPercent = min(max(remainingPercent, 0), 100)
        let text: String
        switch normalizedPercent {
        case 0: text = "0"
        case 100: text = "00"
        default: text = String(format: "%02d", normalizedPercent)
        }
        var pixels = Array(repeating: false, count: 64)
        for (digitIndex, digit) in text.enumerated() {
            guard let rows = digitPixels[digit] else { continue }
            let startColumn = digitIndex * 4
            for (row, pattern) in rows.enumerated() {
                for (column, character) in pattern.enumerated() where character == "1" {
                    pixels[(row + 1) * 8 + startColumn + column] = true
                }
            }
        }
        return pixels
    }

    static func color(forUsedPercent usedPercent: Int) -> PadColor {
        switch min(max(usedPercent, 0), 100) {
        case 0...49: .brightGreen
        case 50...74: .amber
        case 75...89: .orange
        default: .brightRed
        }
    }
}

enum CodexWeeklyUsageDisplayStyle: String, CaseIterable, Codable, Identifiable {
    case level
    case number

    var id: String { rawValue }

    var title: String {
        switch self {
        case .level: "상태 표시"
        case .number: "숫자 표시"
        }
    }
}

struct CodexWeeklyUsageDisplaySettings: Codable, Hashable {
    var isEnabled: Bool
    var scope: CodexMotionDisplayScope
    var pageID: UUID?
    var style: CodexWeeklyUsageDisplayStyle

    init(
        isEnabled: Bool = false,
        scope: CodexMotionDisplayScope = .allPages,
        pageID: UUID? = nil,
        style: CodexWeeklyUsageDisplayStyle = .level
    ) {
        self.isEnabled = isEnabled
        self.scope = scope
        self.pageID = pageID
        self.style = style
    }

    func allowsPresentation(on pageID: UUID) -> Bool {
        switch scope {
        case .allPages: true
        case .specificPage: self.pageID == pageID
        }
    }

    private enum CodingKeys: String, CodingKey {
        case isEnabled
        case scope
        case pageID
        case style
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isEnabled = try container.decodeIfPresent(Bool.self, forKey: .isEnabled) ?? false
        scope = try container.decodeIfPresent(CodexMotionDisplayScope.self, forKey: .scope) ?? .allPages
        pageID = try container.decodeIfPresent(UUID.self, forKey: .pageID)
        style = try container.decodeIfPresent(CodexWeeklyUsageDisplayStyle.self, forKey: .style) ?? .level
    }
}

enum LaunchpadLEDBubbleSize: String, CaseIterable, Codable, Identifiable {
    case small
    case regular
    case large

    var id: String { rawValue }

    var title: String {
        switch self {
        case .small: "작게"
        case .regular: "보통"
        case .large: "크게"
        }
    }

    var points: Double {
        switch self {
        case .small: 124
        case .regular: 156
        case .large: 196
        }
    }
}

enum LaunchpadIdleInputScope: String, CaseIterable, Codable, Identifiable {
    case launchpadAndCodex
    case macAndCodex

    var id: String { rawValue }

    var title: String {
        switch self {
        case .launchpadAndCodex: "기기 입력만"
        case .macAndCodex: "Mac 전체 입력"
        }
    }
}

struct LaunchpadIdleScreensaverSettings: Codable, Hashable {
    static let defaultDelaySeconds = 300
    static let defaultDurationSeconds = 60
    static let minimumDelaySeconds = 5
    static let maximumDelaySeconds = 86_400
    static let minimumDurationSeconds = 5
    static let maximumDurationSeconds = 86_400

    var isEnabled = false
    var inputScope: LaunchpadIdleInputScope = .launchpadAndCodex
    var delaySeconds = defaultDelaySeconds
    var durationSeconds = defaultDurationSeconds
    var presetID: UUID?

    init(
        isEnabled: Bool = false,
        inputScope: LaunchpadIdleInputScope = .launchpadAndCodex,
        delaySeconds: Int = defaultDelaySeconds,
        durationSeconds: Int = defaultDurationSeconds,
        presetID: UUID? = nil
    ) {
        self.isEnabled = isEnabled
        self.inputScope = inputScope
        self.delaySeconds = delaySeconds
        self.durationSeconds = durationSeconds
        self.presetID = presetID
    }

    var clampedDelaySeconds: Int {
        min(max(delaySeconds, Self.minimumDelaySeconds), Self.maximumDelaySeconds)
    }

    var clampedDurationSeconds: Int {
        min(max(durationSeconds, Self.minimumDurationSeconds), Self.maximumDurationSeconds)
    }

    private enum CodingKeys: String, CodingKey {
        case isEnabled
        case inputScope
        case delaySeconds
        case durationSeconds
        case presetID
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isEnabled = try container.decodeIfPresent(Bool.self, forKey: .isEnabled) ?? false
        inputScope = try container.decodeIfPresent(LaunchpadIdleInputScope.self, forKey: .inputScope) ?? .launchpadAndCodex
        delaySeconds = try container.decodeIfPresent(Int.self, forKey: .delaySeconds) ?? Self.defaultDelaySeconds
        durationSeconds = try container.decodeIfPresent(Int.self, forKey: .durationSeconds) ?? Self.defaultDurationSeconds
        presetID = try container.decodeIfPresent(UUID.self, forKey: .presetID)
    }
}

enum LaunchpadIdleScreensaverPolicy {
    static func shouldPlay(
        settings: LaunchpadIdleScreensaverSettings,
        hasPreset: Bool,
        codexIsBusy: Bool,
        launchpadAndCodexIdleSeconds: TimeInterval,
        macIdleSeconds: TimeInterval?
    ) -> Bool {
        guard settings.isEnabled, hasPreset, !codexIsBusy else { return false }

        let idleSeconds: TimeInterval
        switch settings.inputScope {
        case .launchpadAndCodex:
            idleSeconds = launchpadAndCodexIdleSeconds
        case .macAndCodex:
            idleSeconds = min(launchpadAndCodexIdleSeconds, macIdleSeconds ?? 0)
        }
        return idleSeconds >= TimeInterval(settings.clampedDelaySeconds)
    }
}

struct CodexMotionDisplaySettings: Codable, Hashable {
    var scope: CodexMotionDisplayScope = .allPages
    var pageID: UUID?
    var preservesPadLEDsDuringMotion = false
    var showsLaunchpadLEDBubble = true
    var launchpadLEDBubbleSize: LaunchpadLEDBubbleSize = .regular
    var launchpadLEDBubbleOriginX: Double?
    var launchpadLEDBubbleOriginY: Double?
    var idleScreensaver = LaunchpadIdleScreensaverSettings()
    var weeklyUsageDisplay = CodexWeeklyUsageDisplaySettings()

    init(
        scope: CodexMotionDisplayScope = .allPages,
        pageID: UUID? = nil,
        preservesPadLEDsDuringMotion: Bool = false,
        showsLaunchpadLEDBubble: Bool = true,
        launchpadLEDBubbleSize: LaunchpadLEDBubbleSize = .regular,
        launchpadLEDBubbleOriginX: Double? = nil,
        launchpadLEDBubbleOriginY: Double? = nil,
        idleScreensaver: LaunchpadIdleScreensaverSettings = LaunchpadIdleScreensaverSettings(),
        weeklyUsageDisplay: CodexWeeklyUsageDisplaySettings = CodexWeeklyUsageDisplaySettings()
    ) {
        self.scope = scope
        self.pageID = pageID
        self.preservesPadLEDsDuringMotion = preservesPadLEDsDuringMotion
        self.showsLaunchpadLEDBubble = showsLaunchpadLEDBubble
        self.launchpadLEDBubbleSize = launchpadLEDBubbleSize
        self.launchpadLEDBubbleOriginX = launchpadLEDBubbleOriginX
        self.launchpadLEDBubbleOriginY = launchpadLEDBubbleOriginY
        self.idleScreensaver = idleScreensaver
        self.weeklyUsageDisplay = weeklyUsageDisplay
    }

    func allowsPresentation(on pageID: UUID) -> Bool {
        switch scope {
        case .allPages: true
        case .specificPage: self.pageID == pageID
        }
    }

    func shouldPreservePadLEDsDuringMotion(for activity: CodexActivity) -> Bool {
        preservesPadLEDsDuringMotion
    }

    static func restored(
        from persistedData: Data?,
        legacyPresentations: [String: CodexMotionPresentation]
    ) -> (settings: Self, didMigrateLegacyPreservation: Bool) {
        let settings = persistedData
            .flatMap { try? JSONDecoder().decode(Self.self, from: $0) }
            ?? Self()
        let hasPersistedGlobalPreference = persistedData
            .flatMap { try? JSONDecoder().decode(PersistedPreference.self, from: $0) }
            .flatMap(\.preservesPadLEDsDuringMotion) != nil
        let shouldMigrateLegacyPreservation = !hasPersistedGlobalPreference
            && legacyPresentations.values.contains(where: \.preservesPadLEDsDuringMotion)

        guard shouldMigrateLegacyPreservation else {
            return (settings, false)
        }

        var migratedSettings = settings
        migratedSettings.preservesPadLEDsDuringMotion = true
        return (migratedSettings, true)
    }

    private enum CodingKeys: String, CodingKey {
        case scope
        case pageID
        case preservesPadLEDsDuringMotion
        case showsLaunchpadLEDBubble
        case launchpadLEDBubbleSize
        case launchpadLEDBubbleOriginX
        case launchpadLEDBubbleOriginY
        case idleScreensaver
        case weeklyUsageDisplay
    }

    private struct PersistedPreference: Decodable {
        let preservesPadLEDsDuringMotion: Bool?
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        scope = try container.decodeIfPresent(CodexMotionDisplayScope.self, forKey: .scope) ?? .allPages
        pageID = try container.decodeIfPresent(UUID.self, forKey: .pageID)
        preservesPadLEDsDuringMotion = try container.decodeIfPresent(Bool.self, forKey: .preservesPadLEDsDuringMotion) ?? false
        showsLaunchpadLEDBubble = try container.decodeIfPresent(Bool.self, forKey: .showsLaunchpadLEDBubble) ?? true
        launchpadLEDBubbleSize = try container.decodeIfPresent(LaunchpadLEDBubbleSize.self, forKey: .launchpadLEDBubbleSize) ?? .regular
        launchpadLEDBubbleOriginX = try container.decodeIfPresent(Double.self, forKey: .launchpadLEDBubbleOriginX)
        launchpadLEDBubbleOriginY = try container.decodeIfPresent(Double.self, forKey: .launchpadLEDBubbleOriginY)
        idleScreensaver = try container.decodeIfPresent(LaunchpadIdleScreensaverSettings.self, forKey: .idleScreensaver) ?? LaunchpadIdleScreensaverSettings()
        weeklyUsageDisplay = try container.decodeIfPresent(CodexWeeklyUsageDisplaySettings.self, forKey: .weeklyUsageDisplay) ?? CodexWeeklyUsageDisplaySettings()
    }
}

enum CodexMotionRuleControlPlacement: Equatable {
    case mainRuleRow
    case hidden
}

enum CodexMotionRuleLayout {
    static func holdTogglePlacement(for activity: CodexActivity) -> CodexMotionRuleControlPlacement {
        activity == .running ? .mainRuleRow : .hidden
    }
}

struct CodexMotionPresentation: Codable, Hashable {
    var presetID: UUID?
    var dismissal: CodexMotionDismissal = .afterDuration
    var durationSeconds = 5
    var dismissPadID = "grid_0_0"
    var keepsRunningUntilActivityChanges = false
    var preservesPadLEDsDuringMotion = false

    init(
        presetID: UUID? = nil,
        dismissal: CodexMotionDismissal = .afterDuration,
        durationSeconds: Int = 5,
        dismissPadID: String = "grid_0_0",
        keepsRunningUntilActivityChanges: Bool = false,
        preservesPadLEDsDuringMotion: Bool = false
    ) {
        self.presetID = presetID
        self.dismissal = dismissal
        self.durationSeconds = durationSeconds
        self.dismissPadID = dismissPadID
        self.keepsRunningUntilActivityChanges = keepsRunningUntilActivityChanges
        self.preservesPadLEDsDuringMotion = preservesPadLEDsDuringMotion
    }

    var automaticStopDelay: TimeInterval? {
        dismissal == .afterDuration ? TimeInterval(durationSeconds) : nil
    }

    func automaticStopDelay(for activity: CodexActivity) -> TimeInterval? {
        // Live Codex work can spend most of its time reading files or running
        // tools without emitting a new activity event. Keep the motion alive
        // for the entire task; only a terminal activity may stop it.
        if activity == .running || activity == .waitingForApproval {
            return nil
        }
        return automaticStopDelay
    }

    func shouldDismiss(for padID: String) -> Bool {
        switch dismissal {
        case .afterDuration: false
        case .anyPad: true
        case .assignedPad: dismissPadID == padID
        }
    }

    private enum CodingKeys: String, CodingKey {
        case presetID
        case dismissal
        case durationSeconds
        case dismissPadID
        case keepsRunningUntilActivityChanges
        case preservesPadLEDsDuringMotion
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        presetID = try container.decodeIfPresent(UUID.self, forKey: .presetID)
        dismissal = try container.decodeIfPresent(CodexMotionDismissal.self, forKey: .dismissal) ?? .afterDuration
        durationSeconds = try container.decodeIfPresent(Int.self, forKey: .durationSeconds) ?? 5
        dismissPadID = try container.decodeIfPresent(String.self, forKey: .dismissPadID) ?? "grid_0_0"
        keepsRunningUntilActivityChanges = try container.decodeIfPresent(Bool.self, forKey: .keepsRunningUntilActivityChanges) ?? false
        preservesPadLEDsDuringMotion = try container.decodeIfPresent(Bool.self, forKey: .preservesPadLEDsDuringMotion) ?? false
    }
}
